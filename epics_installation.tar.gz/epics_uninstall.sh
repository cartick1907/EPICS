#!/bin/bash
cd /usr/local
sudo rm epics
cd ~
sudo rmdir Apps --ignore-fail-on-non-empty 
sudo rm ~/.bash_aliases