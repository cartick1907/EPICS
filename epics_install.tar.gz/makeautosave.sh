tar -zxvf autosave-R5-7-1.tar.gz  -C ~/Apps/epics/modules/
cd ~/Apps/epics/modules
ln -s autosave-R5-7-1/ autosave
cd ~/Apps/epics/modules/autosave
cd configure
echo "EPICS_BASE=/usr/local/epics/base" >>RELEASE
cd ..
make
