mkdir -p ~/Apps/epics/modules/stream
tar -zxvf StreamDevice-2.tgz -C ~/Apps/epics/modules/stream
cd ~/Apps/epics/modules/stream
echo | makeBaseApp.pl -t support
cd configure
echo "ASYN=/usr/local/epics/modules/asyn" >>RELEASE
cd ~/Apps/epics/modules/stream
make
cd ../StreamDevice-2-6
make