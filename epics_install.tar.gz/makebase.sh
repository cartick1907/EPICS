#!/bin/bash
user=$(whoami)
mkdir -p ~/Apps/epics
tar -zxvf base-7.0.3.tar.gz -C ~/Apps/epics
ln -s ~/Apps/epics/base-7.0.3/ ~/Apps/epics/base
sudo ln -s ~/Apps/epics/  /usr/local
ls -la ~ | grep ~/.bash_aliases
cp .bash_aliases ~/ 
source ~/.bash_aliases
env | grep epics
cd ~/Apps/epics/base
make
