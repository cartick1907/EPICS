#!/bin/bash
mkdir -p ~/Apps/epics/modules
tar -zxf asyn4-38.tar.gz -C ~/Apps/epics/modules/
ln -s ~/Apps/epics/modules/asyn4-38 ~/Apps/epics/modules/asyn
cd ~/Apps/epics/modules/asyn/configure
sed -i 's/IPAC/#IPAC/g' RELEASE
sed -i 's/SNCSEQ/#SNCSEQ/g' RELEASE
sed -i 's/EPICS_BASE/#EPICS_BASE/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >>RELEASE
cd ~/Apps/epics/modules/asyn

#change to be made if ver is 22.04
if [[ $(lsb_release -rs) == "22.04" ]]; then
    cd configure
    sed -i 's/# TIRPC/TIRPC/g' CONFIG_SITE
    cd ..
fi
make