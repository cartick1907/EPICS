#!/bin/bash
cd /usr/local
sudo rm epics
cd ~
rm -rf Apps/
sudo rm ~/.bash_aliases
sudo rm /usr/local/epics  