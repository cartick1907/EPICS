#!/bin/bash
basedir=$(pwd)
./makedependencies.sh
base=~/Apps/epics/base
packages_present=()
packages_left=()
if [ -e "$base" ]; then
    packages_present+=("base")
else
    packages_left+=("base")
fi
asyn=~/Apps/epics/modules/asyn
if [ -e "$asyn" ]; then
    packages_present+=("asyn")
else
    packages_left+=("asyn")
fi
auto=~/Apps/epics/modules/autosave
if [ -e "$auto" ]; then
    packages_present+=("autosave")
else
    packages_left+=("autosave")
fi
stream=~/Apps/epics/modules/stream
if [ -e "$stream" ]; then
    packages_present+=("stream")
else
    packages_left+=("stream")
fi
if [ ${#packages_present[@]} -eq 0 ]; then
    echo No packages present 
else
    echo Packages present 
    for str in ${packages_present[@]}; do
    	echo $str
    done
fi
if [ ${#packages_left[@]} -eq 0 ]; then
    echo No packages left  
else
    echo Packages left to install
    for str in ${packages_left[@]}; do
        echo $str
    done
    read -p "Do you want to install only remaining files or do a clean install?(y,n)" choice

    if [ "$choice" == 'y' ] || [ "$choice" == 'Y' ]; then
        for str in ${packages_left[@]}; do
            script="make${str}.sh"
            ./"$script"
            cd $basedir
        done
    else
		./epics_uninstall.sh
        for str in ${packages_left[@]}; do
        	script="make${str}.sh"
            ./"$script"
            cd $basedir
    	done
    fi
fi

