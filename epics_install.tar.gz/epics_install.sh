#!/bin/bash

#Installation of EPICS base

basedir=$(pwd)
mkdir -p ~/Apps/epics
tar -zxvf base-7.0.3.tar.gz -C ~/Apps/epics
ln -s ~/Apps/epics/base-7.0.3/ ~/Apps/epics/base
sudo ln -s ~/Apps/epics/  /usr/local
ls -la ~ | grep ~/.bash_aliases
touch ~/.bash_aliases
echo "export EPICS_ROOT=/usr/local/epics" >> ~/.bash_aliases
EPICS_ROOT=/usr/local/epics
echo "export EPICS_BASE=${EPICS_ROOT}/base">> ~/.bash_aliases
EPICS_BASE=${EPICS_ROOT}/base
echo "export EPICS_HOST_ARCH=`${EPICS_BASE}/startup/EpicsHostArch`">> ~/.bash_aliases
EPICS_HOST_ARCH=`${EPICS_BASE}/startup/EpicsHostArch`
echo "export EPICS_BASE_BIN=${EPICS_BASE}/bin/${EPICS_HOST_ARCH}">> ~/.bash_aliases
EPICS_BASE_BIN=${EPICS_BASE}/bin/${EPICS_HOST_ARCH}
echo "export EPICS_BASE_LIB=${EPICS_BASE}/lib/${EPICS_HOST_ARCH}">> ~/.bash_aliases
EPICS_BASE_LIB=${EPICS_BASE}/lib/${EPICS_HOST_ARCH}
echo "if [ "" = "${LD_LIBRARY_PATH}" ]; then">> ~/.bash_aliases
echo "export LD_LIBRARY_PATH=${EPICS_BASE_LIB}">> ~/.bash_aliases
LD_LIBRARY_PATH=${EPICS_BASE_LIB}
echo "else">> ~/.bash_aliases
echo "export LD_LIBRARY_PATH=${EPICS_BASE_LIB}:${LD_LIBRARY_PATH}">> ~/.bash_aliases
echo "fi">> ~/.bash_aliases
echo "export PATH=${PATH}:${EPICS_BASE_BIN}" >> ~/.bash_aliases
source ~/.bash_aliases
env | grep epics
cd ~/Apps/epics/base
make

###################################################################

#ASYN package installation

mkdir -p ~/Apps/epics/modules
cd $basedir
tar -zxf asyn4-38.tar.gz -C ~/Apps/epics/modules/
ln -s ~/Apps/epics/modules/asyn4-38 ~/Apps/epics/modules/asyn
cd ~/Apps/epics/modules/asyn/configure
sed -i 's/IPAC/#IPAC/g' RELEASE
sed -i 's/SNCSEQ/#SNCSEQ/g' RELEASE
sed -i 's/EPICS_BASE/#EPICS_BASE/g' RELEASE
echo "EPICS_BASE=/usr/local/epics/base" >>RELEASE
cd ~/Apps/epics/modules/asyn

#change to be made if ver is 22.04
if [[ $(lsb_release -rs) == "22.04" ]]; then
    cd configure
    sed -i 's/# TIRPC/TIRPC/g' CONFIG_SITE
    cd ..
fi
make

####################################################################

#Stream Driver Installation
mkdir -p ~/Apps/epics/modules/stream
cd $basedir
tar -zxvf StreamDevice-2.tgz -C ~/Apps/epics/modules/stream
cd ~/Apps/epics/modules/stream
echo | makeBaseApp.pl -t support
cd configure
echo "ASYN=/usr/local/epics/modules/asyn" >>RELEASE
cd ~/Apps/epics/modules/stream
make
cd ../StreamDevice-2-6
make
sed -i 's/ = /"" = /g' ~/.bash_aliases

####################################################################

#Autosave installation

cd $basedir
tar -zxvf autosave-R5-7-1.tar.gz  -C ~/Apps/epics/modules/
cd ~/Apps/epics/modules
ln -s autosave-R5-7-1/ autosave
cd ~/Apps/epics/modules/autosave
cd configure
echo "EPICS_BASE=/usr/local/epics/base" >>RELEASE
cd ..
make







