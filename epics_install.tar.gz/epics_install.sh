#!/bin/bash
basedir=$(pwd)
base=~/Apps/epics/base
if [ -e "$base" ]; then
    read -p "Base already exists.Clean install?(y/n)" choice
    if [ choice == 'y' ] || [ choice == 'Y' ]; then
        rm -rf ~/Apps/epics/base*
        rm ~/.bash_aliases
        ./makebase.sh
    fi
else
    ./makebase.sh
fi
cd $basedir
asyn=~/Apps/epics/modules/asyn
if [ -e "$asyn" ]; then
    read -p "Aysn already exists.Clean install?(y/n)" choice1
    if [ choice == 'y' ] || [ choice == 'Y' ]; then
        rm -rf ~/Apps/epics/modules/asyn*
        ./makeasyn.sh
    fi
else
    ./makeasyn.sh
fi
cd $basedir
stream=~/Apps/epics/modules/Stream
if [ -e "$stream" ]; then
    read -p "Stream already exists.Clean install?(y/n)" choice1
    if [ choice == 'y' ] || [ choice == 'Y' ]; then
        rm -rf ~/Apps/epics/modules/stream*
        ./makestream.sh
    fi
else
    ./makestream.sh
fi
cd $basedir
auto=~/Apps/epics/modules/autosave
if [ -e "$auto" ]; then
    read -p "Autosave already exists.Clean install?(y/n)" choice1
    if [ choice == 'y' ] || [ choice == 'Y' ]; then
        rm -rf  ~/Apps/epics/modules/autosave*
        ./makeautosave.sh
    fi
else
    ./makeautosave.sh
fi